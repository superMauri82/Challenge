import React , { Component } from 'react'
import {
  Route,
  HashRouter
} from 'react-router-dom'

import { Provider } from 'react-redux'
import storeFactory from '../StoreFactory'

import menu    from '../modules/menu'
import players from '../modules/players'
import home from '../modules/home'

const { PlayersFinder } = players.components
const { Menu }          = menu.components
const { D3Home: Home }  = home.components


class App extends Component{
  render(){
    return(
      <Provider store={storeFactory()} >
        <HashRouter>
          <React.Fragment>
            <Menu />
            <Route component={Home} exact path='/'/>
            <Route component={PlayersFinder} path='/players'/>
          </React.Fragment>
        </HashRouter>
      </Provider>
    )
  }
}

export default App
