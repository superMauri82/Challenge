import React from 'react'
import ReactDOM from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css';
import App  from './app'

const destination = document.querySelector('#root')

ReactDOM.render(<App />, destination)
