import React, { Component } from 'react'
import {
  select,
} from 'd3-selection'

import {
  transition,
} from 'd3-transition'

class D3Home extends Component {
  constructor(props){
    super(props)

    this.svg = null
    this.it  = null
    this.createGraphic = this.createGraphic.bind(this)
  }

  createGraphic(){
    const svg = this.svg
    let w = window,
        d = document,
        e = d.documentElement,
        g = d.getElementsByTagName('body')[0],
        x = w.innerWidth || e.clientWidth || g.clientWidth,
        y = w.innerHeight|| e.clientHeight|| g.clientHeight;

    const group = 
      select(svg)
        .attr('width',x)
        .attr('height',y)
        .append('g')

    // Agregamos elipse sobre la que escribiremos
    group
      .append('path')
      .attr('stroke','blue')
      .attr('id','myPath')
      .attr('fill','none')
      .attr('d', "M10,90 Q90,90 90,45 Q90,10 50,10 Q10,10 10,40 Q10,70 45,70 Q70,70 75,50")


    const text = 
      group
        .append('text')

    text
      .append('textPath')
      .attr('href','#myPath')
      .text('This is the spiralized HOME Title for the Football Player Finder')

    this.it = 
      setInterval( 
        () => 
          group
          .transition()
          .duration(2500)
          .attr('transform',() => 
            `scale(${Math.random()}) translate(${Math.random()*x},${Math.random()*y})`)
        ,
        3000 
      )

  }

  componentDidMount(){
    this.createGraphic()
  }
    
  render(){
    return(
      <svg ref={ (node) => this.svg = node }>
      </svg>
    )
  }

  componentWilUnmount(){
  }
}

export default D3Home
