import React from 'react';
import { 
  Navbar, 
  NavbarBrand, 
  Nav, 
  NavItem, 
  Button
} from 'reactstrap';

import {
  NavLink,
} from 'react-router-dom'


const menu = () =>      
  <div>
    <Navbar fixed="top" color="light" light expand="md">
      <NavbarBrand href="/">Intive-FDV-Challenge</NavbarBrand>
        <Nav className="ml-auto" navbar>
          <NavItem>
            <NavLink to='/' exact> 
              <Button outline color="primary">Home</Button>
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink to='/players' exact> 
              <Button outline color="primary">Players</Button>
            </NavLink>
          </NavItem>
        </Nav>
    </Navbar>
  </div>

export default menu
