import React from 'react'
import PropTypes from 'prop-types'
import { Alert } from 'reactstrap'
import styles from './Player.module.css'

const Player = ({name, position, nationality, jerseyNumber, index}) => {
  const color = index % 2 ? 'success' : 'secondary';
  return(
    <React.Fragment>
      <Alert color={color}>{name}</Alert>
      <Alert color={color}>{position}</Alert>
      <Alert color={color}>{nationality}</Alert>
      <Alert className={styles.jerseyNumber} color={color}>{jerseyNumber}</Alert>
    </React.Fragment>
  )
}

Player.propTypes = {
  name: PropTypes.string,
  position: PropTypes.string,  
  nationality: PropTypes.string,
  jerseyNumber: PropTypes.number
}

export default Player
