import React, { Component } from 'react'
import { createStructuredSelector } from 'reselect'
import { connect } from 'react-redux'
import { getResults, getFilters } from '../selectors'
import { Container } from 'reactstrap'
import { replace } from 'ramda'

import { 
  asyncFilter, 
  filter, 
  addMany, 
  retrievalError  
} from '../actions'
import lib  from '../../../lib'
import { TITLE } from '../constants'
import Heading from './Heading'
import Controls from './Controls'
import Player from './Player'
import styles from './Players.module.css'


class PlayersFinder extends Component {
  constructor(props){
    super(props)

    const {
      players,
      filters,
      onNewFilters,
      fetchPlayers
    } = props

    this.players = players
    this.filters = filters
    this.onNewFilters = onNewFilters
    this.fetchPlayers = fetchPlayers
  }

  componentDidMount(){
    this.fetchPlayers()
  }

  componentWillReceiveProps(nextProps){
    const { players } = nextProps
    this.players = players
  }

  render(){
    return(
      <Container className={styles.grid}>
        <Heading title={TITLE}/>
        <Controls 
          className={styles.freeSpace} 
          onNewFilters={this.onNewFilters} 
          filters={this.filters} 
        />
        { this.players.map( (pl,i) => <Player {...pl} key={`${replace(' ',pl.name)}-${pl.dateOfBirth}`} index={i}  /> )  }
      </Container>
    )
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onNewFilters: (filterObject) => {
      dispatch(asyncFilter(filterObject))
    },
    fetchPlayers: () => { 
      return lib
        .network
        .getPlayers()
        .then( response => dispatch(addMany(response.data) ))
        .catch( error => dispatch(retrievalError(error)) )
    }
  }
}

export default connect(
  createStructuredSelector({
    players: getResults,
    filters: getFilters
  }),
  mapDispatchToProps
)(PlayersFinder)
