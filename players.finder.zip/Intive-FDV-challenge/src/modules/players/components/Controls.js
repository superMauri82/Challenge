import React, { Component } from 'react'
import { 
  Container, 
  Input,
  InputGroup,
  Button,
  InputGroupAddon,
  ButtonDropdown, 
  DropdownMenu, 
  DropdownItem,
  DropdownToggle
} from 'reactstrap';

import { 
  toPairs
} from 'ramda'

import styles from './Controls.module.css'

class Controls extends Component{
  constructor(props){
    super(props)
    const { 
      onNewFilters,
      filters 
    } = this.props

    this.state = {
      dropdownOpen: false,
      splitButtonOpen: false,
      value: "Keeper"
    };

    this.filters        = filters
    this.onNewFilters   = onNewFilters
    this.handleChange   = this.handleChange.bind(this)
    this.handleSearch   = this.handleSearch.bind(this)
    this.toggle         = this.toggle.bind(this);
    this.select         = this.select.bind(this);
  }

  select(e) {
    this.filters['position']= e.target.innerText

    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
      value: e.target.innerText
    });
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }

  handleSearch(e){
    e.preventDefault()
    this.onNewFilters(this.filters)
  }

  handleChange(e){
    const name = e.target.name
    this.filters[name]= e.target.value
  }

  componentWillReceiveProps(nextProps, nextState){
    const { filters } = nextProps
    this.filters = filters
  }

  render(){
    const filters = toPairs(this.filters)
    return (
      <React.Fragment>
        <Container>
          <InputGroup>
            <InputGroupAddon addonType="prepend">Name</InputGroupAddon>
            <Input onChange={this.handleChange} name='name' type='text'  placeholder="..." />
          </InputGroup>
        </Container>
        <Container>
          <ButtonDropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
            <InputGroupAddon addonType="prepend">Position</InputGroupAddon>
            <DropdownToggle split outline />
            <DropdownMenu>
              <DropdownItem onClick={this.select} header>...</DropdownItem>
              <DropdownItem onClick={this.select}>Centre-Forward</DropdownItem>
              <DropdownItem onClick={this.select}>Keeper</DropdownItem>
              <DropdownItem onClick={this.select}>Centre-Back</DropdownItem>
              <DropdownItem onClick={this.select}>Left-Back</DropdownItem>
              <DropdownItem onClick={this.select}>Defensive Midfield</DropdownItem>
              <DropdownItem onClick={this.select}>Central Midfield</DropdownItem>
              <DropdownItem onClick={this.select}>Left Midfield</DropdownItem>
              <DropdownItem onClick={this.select}>Attacking Midfield</DropdownItem>
              <DropdownItem onClick={this.select}>Left Wing</DropdownItem>
              <DropdownItem onClick={this.select}>Centre-Forward</DropdownItem>
              <DropdownItem onClick={this.select}>Defensive Midfield</DropdownItem>
            </DropdownMenu>
          <Input name='position' onChange={this.handleChange} type='text' value={this.state.value} placeholder="..." />
          </ButtonDropdown>
        </Container>
        <Container>
          <InputGroup>
            <InputGroupAddon addonType="prepend">Age</InputGroupAddon>
            <Input onChange={this.handleChange} name='age' type='number' min='18' max='40' placeholder='18' />
          </InputGroup>
        </Container>
           <Button 
             outline 
             color="secondary"
             onClick={this.handleSearch} 
             className={`${styles.searc} search`}>
               Search
           </Button>
      </React.Fragment>
    )
  }
}

export default Controls


