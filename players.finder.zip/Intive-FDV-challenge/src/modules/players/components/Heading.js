import React from 'react';
import { Jumbotron, Container } from 'reactstrap';
import styles from './Heading.module.css'

const Heading  = ({title}) => {
  return (
    <Jumbotron className={`${styles.gridHeader} bg-dark text-light`}>
      <Container fluid>
        <h1 className="display-3">{title}</h1>
      </Container>
    </Jumbotron>
  );
};

export default Heading;
