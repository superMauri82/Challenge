import * as t from './actionTypes'
import lib  from '../../lib'
import { filterByCriteria } from './model'

export const addMany = 
  ( players ) =>
    ({
        type: t.ADD_MANY,
        players
    })

export const filter = 
  ( criteria ) =>
    ({
        type: t.FILTER,
        criteria
    })

export const retrievalError = 
  ( error ) =>
    ({
        type: t.ERROR,
        error
    })

export const asyncFilter = 
  (criteria) =>  
    (dispatch) => 
      lib
        .network
        .getPlayers()
        .then( response => dispatch(addMany(filterByCriteria(criteria,response.data) )) )
        .catch( error => dispatch(retrievalError(error)) )
