import { combineReducers } from 'redux'
import * as t from './actionTypes'
import type { State } from './model'
import { filterByCriteria } from './model'

const initialState: State = {
  filters: {
    name : "",
    position : "Keeper",
    age : 18
  },
  results: [ 
  ]
}

const results = (state = initialState.results, action: any): State => {
  switch (action.type){
    case t.ADD_MANY: 
      return addPlayers(state, action)
    case t.FILTER: 
      return filterPlayers(state, action)
    case t.ERROR: 
      return signalError(state, action)
    default:
      return state;
  }
}

const filters = (state = initialState.filters, action: any): State => {
  switch (action.type){
    case t.FILTER: 
      return updateFilters(state, action)
    default:
      return state;
  }
}

const addPlayers = (state, action) => {
  return [
    ...action.players
  ]
}

const filterPlayers = (state=[], action) => {
  return filterByCriteria(state,action.criteria)
}

const updateFilters = (state={}, action) => {
  return {
    ...state,
    ...action.criteria
  }
}

const signalError = (state=[], action) => {
  return []
}

export default combineReducers({
  results,
  filters
})
