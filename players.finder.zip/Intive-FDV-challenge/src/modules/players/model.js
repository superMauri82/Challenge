import { 
  toPairs,
  test,
  curry,
  is,
  identical
} from 'ramda'

import * as moment from 'moment'

export type Player = {
  id?: string,
  dateOfBirth: string,
  name: string,
  position: string,
  nationality: string,
  jerseyNumber: number
}


export type State = Player[]

export const filterByCriteria = (criteria,players) => {
  const arrayCriteria = toPairs(criteria)
  const initialValue  = false

  return players.filter( pl => 
    arrayCriteria.reduce( 
      (acc,currentArray) => {
        return isNumberAndNotNaN(Number(currentArray[1])) ?  
          isSameAge(pl['dateOfBirth'],currentArray[1]) || acc :
          containsString(pl[currentArray[0]],currentArray[1]) || acc
    }, 
      initialValue 
    ) 
  ) 
}

const curryFilterByCriteria = curry(filterByCriteria)
export const filterBy = criteria => curryFilterByCriteria(criteria)

const containsString = (str,substr) => String(str).includes(String(substr))
const curryIs = curry(is)
const isNumber =  curryIs(Number)
const isNumberAndNotNaN =  (numberWannaBe) => isNumber(numberWannaBe) &&  !identical(NaN, numberWannaBe)
const isSameAge = (dateOfBirth,age) => {
  return moment().diff(dateOfBirth,'years') == age 
}


