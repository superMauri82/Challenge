export const NAME = 'players'
export const TITLE = 'Football Player Finder'
