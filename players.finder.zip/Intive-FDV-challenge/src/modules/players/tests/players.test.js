import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';



import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';
import sinon from 'sinon';

import Controls from '../components/Controls';
import { Input, DropdownItem } from 'reactstrap'

configure({ adapter: new Adapter() });

describe('<Controls />', () => {
  it('renders 3 <Input /> components', () => {
    const wrapper = shallow(<Controls />);
    expect(wrapper.find(Input)).to.have.lengthOf(3);
  });

  it('triggers filters events on search button press', () => {
    const onButtonClick = sinon.spy();
    const wrapper = mount(<Controls onNewFilters={onButtonClick} />);
    wrapper.find('button.search').simulate('click');
    expect(onButtonClick).to.have.property('callCount', 1);
  });

});
