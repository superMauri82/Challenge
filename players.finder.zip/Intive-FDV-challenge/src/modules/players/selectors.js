import { createSelector } from 'reselect'
import { 
  compose, 
  curry,
  identity 
} from 'ramda'
import { NAME } from './constants'
import { filterBy } from './model'
import { filterActive, filterCompleted } from './model';

export const getFilters = state => state[NAME].filters
export const getResults = state => state[NAME].results
